#pragma once

namespace Net
{
enum class Mode
{
    Offline,
    Online
};
}
